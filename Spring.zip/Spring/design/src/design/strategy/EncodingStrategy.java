package design.strategy;

public interface EncodingStrategy {

    String encode(String text);
}
