package design.decorator;

public interface ICar {

    int getPrice();
    void showPrice();

}
