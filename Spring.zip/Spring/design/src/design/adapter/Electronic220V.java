package design.adapter;

public interface Electronic220V {

    void connect();
}
