package design.adapter;

public interface Electronic110V {

    void powerOn();
}
