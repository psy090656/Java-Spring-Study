package design.proxy;

public interface IBrowser {

    Html show();
}
