package design.observer;

public interface IButtonListener {

    void clickEvent(String event);
}
