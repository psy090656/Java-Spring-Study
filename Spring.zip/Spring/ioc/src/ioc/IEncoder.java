package ioc;

public interface IEncoder {
    String encode(String message);
}
