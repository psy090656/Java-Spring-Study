package com.example.delete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeleteApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeleteApplication.class, args);
    }

}
